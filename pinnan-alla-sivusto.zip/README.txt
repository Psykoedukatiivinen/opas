
Tämä on opinnäytetyön verkkopohjainen opas ahdistuksesta (Pinnan alla – Susanna Kauranen & Sonja Nissi).

Julkaisuvaiheet:
1. Luo GitHub-tunnus osoitteessa: https://github.com
2. Luo uusi julkinen repository (esim. nimellä 'ahdistusopas')
3. Lataa kaikki tämän ZIP-paketin tiedostot repositoryyn
4. Mene repositoryn asetuksiin → Pages → valitse julkaisu 'main' branchista juurihakemistosta (/)
5. Sivusto on näkyvissä osoitteessa: https://KÄYTTÄJÄNIMESI.github.io/ahdistusopas/

Muokkaus:
- Tekstit löytyvät tiedostoista index.html, opas.html ja yhteydenotto.html
- Tyylitiedosto on styles.css – voit vaihtaa värejä tai fontteja sieltä
- Kuvia voit lisätä korvaamalla [KUVA]-kohdat <img src="polku/kuva.jpg"> -elementeillä

Onnea verkkosivuston julkaisuun!
